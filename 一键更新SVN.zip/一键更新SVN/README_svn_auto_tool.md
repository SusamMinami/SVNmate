# 一键更新SVN

这是一个 Windows 桌面小工具，用来批量执行多个文件夹的 SVN 更新、清理和项目脚本。

多项目文档入口见
[`docs/README.md`](https://github.com/SusamMinami/SVNmate/blob/main/docs/README.md)。

## v1.4.7 更新摘要

- 修复同一任务组内不同 Working Copy Root 仍被串行执行的问题。
- 所有启用路径会先按 WC Root 拆成执行通道，`bin`、`doc`、`res` 分属独立
  工作副本时可同时更新。
- 全局最多并发三个不同 WC；同一 WC 和无法识别 Root 的路径仍自动排队，避免
  并发写入同一个 `.svn\wc.db`。
- SVNmate 主界面与共享更新核心使用相同的三路调度上限。

## v1.4.6 更新摘要

- 点击“重启并安装”后，更新器改由 Windows ShellExecute 独立启动；启动失败会
  保留当前窗口并显示原因，不再静默退出或无响应。
- 更新脚本会等待旧程序完全释放、替换文件、启动新实例，并检查新实例是否立即
  退出；详细过程保存在 `_updates\apply_update.log`。
- SVN 子进程不再继承可能失效的标准句柄。检测到 `[WinError 6] 句柄无效` 时，
  本轮任务立即停止并由独立守护脚本自动重启 SVNmate；结果保存在
  `_updates\restart_svnmate.log`。

## v1.4.5 更新摘要

- 顶部音乐和“隐藏到托盘”改为固定尺寸图标按钮，并提供 Tooltip 与
  `Alt+M` / `Alt+H` 快捷键。
- 当前状态移动到 `SVNmate` 名称右侧，右上角只保留图标命令与“立即执行”。
- 保存配置、日志目录、使用指南、更新与退出收纳到顶部“更多”菜单。
- 工具模块行压缩为“名称 + 版本状态 + 主动作 + 更多菜单”；检查更新、重新
  选择、打开安装位置和复制路径进入行级菜单。
- 实时输出标题旁增加成功、失败和跳过计数；存在失败时不再显示绿色完成状态。
- 主题色板与 ttk 样式抽到独立模块，并在 DPI 切换后同步更新窗口最小尺寸。
- 在线升级兼容平铺和带外层目录的 ZIP，并在替换前验证主程序文件。
- 执行与自动化区将定时设置并入标题行，移除重复说明与分隔行，扩大实时日志。

## v1.4.4 更新摘要

- 正式提供 Named Pipe 外部更新接口和共享 `svnmate_core`。
- 新增迁移核验助手及独立在线更新通道。
- 迁移核验助手按单据涉及路径执行精细 SVN 更新，不再默认更新整个 trunk。
- 增加固定阶段进度条，并在 checkout 后按提交日志和本地状态完整复核。

## v1.4.3 更新摘要

- Explorer 重启后会自动重新注册托盘图标。
- 隐藏主窗口前会检查托盘图标；若恢复失败，窗口保持打开并显示原因。
- 空闲时降低日志、托盘、定时任务和 DPI 检查频率，减少后台唤醒。
- 保留单实例唤醒、每日定时更新及现有 SVN 执行流程。

## v1.4.2 更新摘要

- 软件只保留一个运行实例；重复启动时先提示，再恢复并激活已有窗口。
- 常驻实例通过本机 Named Pipe 接收其他 SVNmate 模块的指定目录更新请求。
- 双击托盘图标可在“显示并激活”和“隐藏到托盘”之间切换。
- 托盘右键菜单可直接打开配置关系检索器或 Kindle 提示板，不需要先打开主窗口。
- 实时日志队列、单条内容和界面行数均有上限，完整内容继续写入磁盘日志。
- 命令行 SVN 输出逐行处理，只在内存中保留有限的错误尾部。

## v1.4.1 更新摘要

本版本新增独立工具模块体系：

- 工作目录支持右键打开，可直接进入所选文件夹。
- SVN Update 失败时会自动 Cleanup，并重试一次 Update。
- 设置区调整为“执行与自动化”和“工具模块”两张卡片。
- ConfigLinker 与 KindleLarkStatus 均可按需安装或选择已有 EXE，且不进入 SVNmate 主安装包。
- 支持打开、选择现有 EXE、检查和在线安装模块；Kindle 公共通道已经启用。
- 两个模块使用各自的固定 Release 端点，不会覆盖 SVNmate 主程序更新。
- 下载前校验 manifest 模块 ID、HTTPS 地址、版本、入口文件和 SHA-256。
- ZIP 解压拒绝目录穿越；替换只允许模块 EXE 和公开 `VERSION`。
- 模块配置、日志、OAuth Token、SSH 私钥和其他运行文件不在更新白名单内。
- 运行中的模块会在用户确认后关闭、替换并按原状态重启。
- ConfigLinker `1.2.1` 使用独立关系网络图标，修复高 DPI 字体和默认窗口尺寸。
- ConfigLinker 支持查询中心高亮、双击 ID 复制、长路径横滚/选择复制，坐标和旋转在选中详情中同一行显示。
- ConfigLinker 数据入口改为 `doc` 根目录，自动定位 `doc\csvdir` 下的三张 CSV。

## 启动方式

双击：

```text
dist\SVNAutoTool.exe
```

如果你想用源码方式运行，也可以双击：

```bat
run_svn_auto_tool.bat
```

或在当前目录执行：

```bat
python svn_auto_tool.py
```

运行 exe 不需要额外安装 Python。工具会优先使用 TortoiseSVN 的 `TortoiseProc.exe` 执行 update/cleanup，这和右键菜单行为更接近；如果找不到 TortoiseSVN，才会回退到命令行 `svn.exe`。

其他本机工具可调用 `migration_guard.update_working_copies` 请求更新指定目录。SVNmate
常驻时由 SVNmate 执行；未运行时调用方使用共享的 `svnmate_core`。如果检测到旧版
SVNmate 正在运行但 IPC 不可用，调用方会停止并提示重启，避免两个进程同时操作同一
工作副本。

执行 TortoiseSVN update 时，工具会在确认窗口已经完成后自动点击 `OK/确定/确认/关闭`；执行 cleanup 时会使用 TortoiseSVN 的 `/noui` 静默清理，避免弹出确认窗口。

右上角的音乐图标用于播放或暂停。默认开启，工具会优先播放 exe 所在目录下的
`.mp3` 音乐文件，也兼容 `.wav`；悬停可查看当前状态，也可按 `Alt+M` 切换。

全部任务完成后，音乐会淡出并暂停。

界面采用紧凑的 Metro 风格：Segoe UI 字体、扁平卡片、蓝色强调按钮和高对比度昼夜主题。设置区左侧是“执行与自动化”，右侧是“工具模块”。Windows 端启用 Per-Monitor V2 DPI 感知，在 125%/150% 缩放和多显示器环境下会按当前显示器 DPI 重新校准字体，避免系统拉伸造成文字发虚。

界面右下角会显示作者签名 `SusamMinami`，签名左侧的圆点用于检查更新；检测到新版本后圆点会变红，点击即可下载并应用更新。软件会根据时间自动切换外观：19:00 后进入暗黑主题，白天保持浅色主题。

顶部“更多”菜单提供保存配置、日志文件夹、使用指南、检查更新和退出；
`Ctrl+S` 可直接保存配置。点击“使用指南”会打开在线文档：

```text
https://bytedance.larkoffice.com/docx/BdDod9tjIo4rPbx2oWHchVRUnwh
```

## 工具模块

“工具模块”卡片提供四个独立模块：

```text
配置关系检索器（ConfigLinker）
迁移核验助手（MigrationGuard）
Seria QA Overlay
Kindle 提示板（KindleLarkStatus）
```

每行固定显示模块名称、版本状态、一个主动作和“更多”图标。主动作会根据状态
显示“安装”“打开”或“更新”；检查更新、选择现有程序、打开安装位置、复制路径
以及 Kindle 的启动联动设置位于行级菜单中。

### 按需安装

模块未安装时点击“安装”。SVNmate 会读取对应的固定 manifest、下载 ZIP、校验 SHA-256，再安装到：

```text
modules\ConfigLinker\ConfigLinker.exe
modules\SeriaQAOverlay\Install-SeriaQA.cmd
modules\KindleLarkStatus\KindleLarkStatus.exe
```

迁移核验助手使用独立的 `migration-guard-latest` 在线更新通道；同时仍会从同目录
或 `dist\MigrationGuard.exe` 自动识别，也可手动选择。
Seria QA Overlay 使用 `seria-qa-overlay-latest` 固定通道。安装或更新时必须先
退出 `Seria.exe`；SVNmate 校验完整 ZIP 后调用包内安装器，将 QA 组件应用到
`%SERIA_TRUNK%` 或默认 `C:\trunk`，并更新 trunk 外的恢复副本。
其他模块不随 `SVNmate.zip` 预装。安装失败不会删除当前可用版本，也不会覆盖模块配置。

MigrationGuard `1.0.5` 的无工程模式会缓存远端结果 5 分钟，并可按 2 分钟或
5 分钟周期自动刷新。配置了有效本地工作区后，“更新并复核”会先让用户选择本批
资产，只更新相关 SVN 目录，并让后续迁移、提交和 OSOB 阶段沿用同一范围。

### 选择已有程序

已有独立 EXE 时点击对应行的“选择”：

- ConfigLinker 必须选择 `ConfigLinker.exe`。
- 迁移核验助手必须选择 `MigrationGuard.exe`。
- Kindle 提示板必须选择 `KindleLarkStatus.exe`。
- Seria QA Overlay 仅使用 SVNmate 管理的完整安装包，不允许选择单个 DLL 或脚本。
- 新的 `tool_module_paths` 会保存到 `svn_auto_tool_config.json`。
- 旧版 `kindle_status_path` 会自动迁移，不需要重新选择。

### 检查与更新

SVNmate 启动后会后台检查支持在线发布的模块。网络失败只把模块状态改为“检查失败”，不影响 SVN 更新、本地迁移核验或已安装模块启动。

- 无更新时保持当前版本。
- 有更新时该行主动作变为“更新”，仍可从“更多”菜单直接打开当前版本。
- 更新前必须人工确认，不会静默替换。
- 模块正在运行时会先提示关闭；更新完成后按原状态重启。
- EXE 模块只替换 EXE 和公开 `VERSION`；安装包型模块只替换已校验的模块副本并
  调用自身安装器。两类更新均不覆盖无关 JSON/INI 配置、日志、Token、缓存或 SSH 私钥。

ConfigLinker 还可以在自身标题区点击更新圆点独立更新。SVNmate、ConfigLinker 和 KindleLarkStatus Windows 模块拥有各自版本，互不覆盖。

KindleLarkStatus 源码仓保持私有；Windows 模块通过 SVNmate 仓库的独立 `kindle-windows-latest` 公共通道发布，可匿名读取 manifest、安装和更新。发布与验收记录见 [Kindle 公共更新通道交接](https://github.com/SusamMinami/SVNmate/blob/main/KINDLE_PUBLIC_CHANNEL_HANDOFF.md)。

## ConfigLinker 使用

完整操作说明：[ConfigLinker 使用指南](https://github.com/SusamMinami/SVNmate/blob/main/config_id_lookup/USER_GUIDE.md)。

1. 打开“配置关系检索器”。
2. 点击右上角“设置 > 选择 doc 目录”，选择包含 `csvdir` 的配置仓 `doc` 根目录。
3. 选择目标物 ID、NPC ID 或模型资源 ID，输入整数后搜索。
4. 单击结果中的关系 ID 可切换查询中心，点击左箭头可连续回退。
5. 双击 ID 会复制完整数字并显示提示。
6. 模型资源路径可横向滚动；下方只读输入框支持框选和 `Ctrl+C`。
7. 选中目标物后，坐标和旋转会在“选中详情”中同一行显示，双击字段可复制。
8. 点击“设置 > 同步角色档案”可从飞书 Base 同步有效命名角色及 NPC 归属。
9. 选中已关联的命名 NPC 后，点击“角色详情”查看标签、摘要、性格、经历、任务、台词和剧情。
10. 点击版本号左侧的“武器查询”，可按武器名称、装备 ID、转换组 ID 或模型 ID 查询。
11. 武器页签只读取正式服数据，并展示职业、同类武器、同职业系列、同模型装备和模型名称。
12. 两个功能的查询框都位于返回图标右侧；武器简介位于左下方，可直接选择复制。
13. 有在线资源的武器会在详情中显示图标；首次查看时下载，之后直接读取本地缓存。

程序自动读取：

```text
doc\csvdir\m目标物表.csv
doc\csvdir\NPC表.csv
doc\csvdir\m模型资源表.csv
```

武器查询额外读取 `doc\csvdir` 下的 `z装备表.csv`、`w武器转换表.csv`、`w武器外观表.csv` 和 `z职业配置表.csv`，不读取 `csvspecial`。

如果误选 `csvdir`，程序会自动使用父级 `doc`。ConfigLinker 只读 CSV，不保存 Excel，不运行 VBA、导表器或配置检查脚本。

ConfigLinker `1.3.0` 的角色档案同步依赖本机 `lark-cli` 和 Base 只读授权。任务、台词和剧情直接读取当前 `doc\csvdir` 的本地配置，不从飞书下载。通用角色、待确认角色不会展示。角色档案缓存位于 `%LOCALAPPDATA%\SVNmate\ConfigLinker`，网络失败时继续使用上一份成功缓存。

ConfigLinker `1.5.3` 的武器图标也通过 `lark-cli` 从飞书 Base 只读获取。图标索引每天最多刷新一次，PNG 按需缓存在 `%LOCALAPPDATA%\SVNmate\ConfigLinker\weapon_icons`；公开安装包不包含在线图标。

## Kindle 提示板联动与更新

在 Kindle 提示板模块行勾选“启动时联动”后，每次启动 SVNmate 会打开提示板；已运行时不会重复启动。退出 SVNmate 不会关闭提示板托盘服务。

必须区分两种更新：

- **更新 Windows 模块**：更新器通过公共固定端点在线检查并替换 `KindleLarkStatus.exe`。
- **更新 Kindle 端**：由 KindleLarkStatus 自身通过 SSH 更新 KUAL 元数据和 Kindle Shell 文件，不替换 Windows EXE。

## 系统托盘

SVNmate 启动后会在 Windows 通知区域显示 Metro 蓝色图标。

- 点击窗口关闭按钮或“隐藏到托盘”只会隐藏窗口，定时任务仍会继续。
- 双击托盘图标：主窗口可见时隐藏，否则恢复并激活。
- 右键托盘图标可选择“打开 SVNmate”“立即执行”、直接打开各工具模块或“退出”。
- 软件已在运行时再次双击 EXE，会提示当前状态并唤醒已有窗口，不会产生第二个托盘进程。
- 只有选择托盘菜单中的“退出”才会彻底关闭 SVNmate。

## 重新打包

如果修改了 `svn_auto_tool.py`、`tool_modules.py`、`module_updates.py` 或相关资源，双击下面的文件可以重新生成 exe：

```bat
build_exe.bat
```

打包结果会输出到：

```text
dist\SVNAutoTool.exe
```

## 文件夹配置

文件夹分为“栏目一”和“栏目二”两栏，每栏左上角都有“添加文件夹”按钮。

每一行是一个任务组并共享一个执行开关。列表中的 `[x]` 表示整组会参与执行，
`[ ]` 表示整组暂不执行；点击“执行”列头可以全选或全不选当前栏目。

- 把一行拖到另一行上，会把两个任务组合并；整组共享执行开关，不同 Working
  Copy Root 仍可并发更新。
- 把包含多个文件夹的行拖到当前栏目空白处，会拆分为独立任务组。
- 把一行拖到另一栏空白处，会把整个任务组移到该栏。
- 右键任务组可以打开其中任意文件夹，也可以直接拆分或与上一组合并。

单个任务组不限制文件夹数量。旧版配置中的单个文件夹会自动迁移为单路径任务组。

点击“保存配置”后，文件夹路径、勾选状态、执行选项、定时设置、工具模块路径和 Kindle 联动设置都会保存；下次打开软件会自动恢复。

## 执行流程

工具使用任务组与 Working Copy Root 双重调度：

1. 启动前识别所有启用路径所属的 Working Copy Root，并拆成独立执行通道。
2. 同时最多更新三个不同 Root；任务组只控制组合显示和启用状态，不会阻止组内
   不同 Root 并发。相同 Root 即使属于不同任务组，也会自动排队，禁止并发写
   同一个 `.svn\wc.db`。
3. Update 失败时立即 cleanup，清理成功后只重试一次。
4. `bin` 更新成功后，`Update.bat` 进入单线程后台队列；它可以和其他 Working
   Copy 的 Update 重叠，但与同一 Root 的 SVN 操作互斥。
5. 等待全部 SVN Update 和后台 `Update.bat` 完成。
6. 按配置顺序执行 `svn cleanup`，并按设置执行对应 `Build.bat`。

无法识别 Working Copy Root 的路径统一进入保守串行通道，不会冒险并发。

如果 `svn update` 返回失败，工具会自动执行一次 `svn cleanup`，清理成功后重试一次 `svn update`。重试仍失败时会记录错误并继续后续文件夹，不会循环重试。

执行 `Update.bat` 和 `Build.bat` 时会显示原始 CMD 窗口；工具会自动给窗口发送 Enter 来通过脚本里的 `pause`。脚本成功结束后窗口会关闭，如果脚本返回错误，窗口会保留 5 秒方便查看。全部任务结束后，实时输出标题旁会显示成功、失败和跳过数量；只有没有失败或跳过时日志区域才显示绿色完成状态。

## 自定义脚本位置

执行选项里可以手动选择 `Update.bat` 和 `Build.bat` 的位置。

- 不选择时，继续使用默认规则：`bin\\WindowsNoEditor\\Update.bat` 和 `res\\Build.bat`
- 如果选择的 bat 位于已配置的 SVN 文件夹下，工具会优先保存相对路径，便于切换不同分支时复用相同层级
- 如果选择的 bat 不在已配置文件夹下，工具会保存并执行绝对路径
- 点击“默认”可以清空自定义位置并恢复默认识别规则

## 路径识别规则

工具支持两种添加方式：

- 直接添加项目根目录：工具会检查 `bin\\WindowsNoEditor` 和 `res`
- 直接添加 `bin` 或 `res` 文件夹：工具也会按对应规则执行

## 配置和日志

配置会自动保存到：

```text
svn_auto_tool_config.json
```

执行日志会按天保存到：

```text
logs\svn_auto_tool_YYYY-MM-DD.log
```

配置文件和日志目录会在第一次使用后自动生成。使用 exe 时，它们会保存在 `SVNAutoTool.exe` 所在目录。

模块路径保存在配置中的 `tool_module_paths`。ConfigLinker 自己的 doc 目录保存在其 EXE 同目录的 `config_linker_config.json`；KindleLarkStatus 的私有配置仍位于 `%APPDATA%\KindleLarkStatus`，SVNmate 不读取这些内容。

工具启动时会自动清理 7 天前的日志文件。

## 定时执行

勾选“启用每天定时执行”，填写 `HH:MM` 格式时间即可，例如：

```text
09:00
```

工具需要保持打开状态，才能按时触发任务。
